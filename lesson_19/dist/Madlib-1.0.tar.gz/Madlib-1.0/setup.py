#! /usr/bin/env python

from distutils.core import setup

setup(name="Madlib",
	version="1.0",
	descriptionj="A madlib generator",
	author="Jesse Shawal",
	py_module=['madlib'])